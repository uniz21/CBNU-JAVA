import java.awt.*;
public class FrameTest1
{
	public static void main(String args[])
	{
		Frame f=new Frame();
		f.setTitle("ù��° ������ �Դϴ�.");
		f.setBounds(100,100,300,300);
		f.setVisible(true);
	}
}