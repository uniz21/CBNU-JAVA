
public class onearray {
	public static void maijn(String[] args){
		int [] ar={10,20,30};
		for(int i=0;i<ar.length;i++){
				System.out.println("ar["+i+"]="+ar[i]);
		}
	}
}
