package ex8;
public class ex9 {
	public static void main(String[] args) throws Exception
	{
	throw new UnsupportedFunctionException("�������� �ʴ� ����Դϴ�.",100);
	}
}

class UnsupportedFunctionException extends RuntimeException
{
	final private int ERR_CODE;
	UnsupportedFunctionException(String msg,int errorcode){
		
		ERR_CODE=errorcode;
		System.out.println("UnsupportedFuctionException: ["+errorcode+"] "+msg);
	}
	public int getErrorCode() {
		return ERR_CODE;
	}
	public String getMessage() {
		return "";
	}
	
}

